


<?php $__env->startSection('contant'); ?>

<section class="Home-page" id="Home-page" >
  <div class="container-fluid d-none" id="blur">
  <nav class="navbar navbar-expand-lg bg-body-tertiary fixed-top "> 
    <div class="container-fluid">
      <a class="navbar-brand ms-2 " href="#"><img class ="logo-nav" src="image/jam_ticket-f.png" alt=""></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <!-- <button type="button" class="btn btn-primary btn-sm me-5 bg-white text-dark fw-bolder btn-outline-danger" id="signlogin" >Login / Sign Up</button> -->
      </div>
    </div>
  </nav>
</div>   
<div class="tab-form " id="popup-tab-form">
  <div class="tab-header">  
      <div >Sign Up</div>
  </div>
    <div class="tab-body" >

        <form class="sign-in active" action="<?php echo e(route('creatuser')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <!-- <?php echo method_field('POST'); ?> -->


          <div class="form_input2 ">
            <label for="First_Name">First Name</label>
            <?php $__errorArgs = ['first_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="text" name="first_Name" id="First_Name" required>
          </div>


          <div class="form_input2 ">
            <label for="Last_Name">Last Name</label>
            <?php $__errorArgs = ['last_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="text" name="last_Name" id="Last_Name" required>
          </div>


          <div class="form_input ">
            <label for="National_ID" >National ID</label>
            <?php $__errorArgs = ['national_ID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <input type="text" name="national_ID" id="National_ID" required>
          </div>


          <div class="form_input2">
            <label for="date_birth" >date of birth</label>
            <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <input type="text" name="date_of_birth" id="date_birth" required>
          </div>


          <!-- <div class="form_input2">
              <label for="profession" >profession</label>
              <input type="text" name="profession" id="profession" required>
          </div> -->


          <div class="form_input2">
            <label for="Health_status" >Health_status</label>
            <?php $__errorArgs = ['health_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <input type="text" name="health_status" id="Health_status" class="National_IDx" required>
          </div>


          <div class="form_input2">
              <label for="gender" >gender</label>
              <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <input type="text" name="gender" id="gender" required>
          </div>


          <div class="form_input">
            <label for="phone" >phone</label>
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="phone" name="phone" id="phone" required>
          </div>

          
          <div class="form_input">
            <label for="Email" >Email</label>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <input type="email" name="email" id="Email" required>
          </div>


          <div class="form_input">
            <label for="password" >Password</label>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="password" name="password" id="password" required>
            

          </div>
          <div class="form_input"><label for="confirm_password">confirm_password </label>
          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="password" name="password_confirmation" id="confirm_password" required>
          </div>

          <div class="form_input">
            <button type="submit" class="sign_up_btn "> sign up</button>
          </div>
          </form> 
        </div>
        <a href="/index.html" class="close-btn" id="close-btn" target="_blank">&times;</a> 
  
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.HeaderAndFooter", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\easy_ticket_web\laravel-app\resources\views/signup.blade.php ENDPATH**/ ?>