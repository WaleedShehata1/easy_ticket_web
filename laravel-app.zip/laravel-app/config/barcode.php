<?php

return [
    'store_path' => public_path("/"),
];
